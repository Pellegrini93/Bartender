

package com.vncode247.splashscreen


import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast


class SegundaTela : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda_tela)




    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater
        menuInflater.inflate(R.menu.menu, menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.bebidas ->Toast.makeText(this, "Acessando Bebidas", Toast.LENGTH_SHORT).show()
            R.id.comidas ->Toast.makeText(this, "Acessando Comidas", Toast.LENGTH_SHORT).show()
            R.id.contato -> Toast.makeText(this, "Acessando Contato", Toast.LENGTH_SHORT).show()
            R.id.Email -> Toast.makeText(this, "Acessando E-mail", Toast.LENGTH_SHORT).show()
            R.id.Comanda -> Toast.makeText(this, "Acessando Comanda", Toast.LENGTH_SHORT).show()
        }
        return super.onOptionsItemSelected(item)
    }

}




