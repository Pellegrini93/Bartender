package com.vncode247.splashscreen

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Toast.makeText(this, "Bem Vindo ao Bar!", Toast.LENGTH_SHORT).show()

        val button = findViewById<Button>(R.id.Entrar)

        button.setOnClickListener {

            val intent = Intent(this, SegundaTela::class.java)
            startActivity(intent)
            finish()
        }
    }
}
